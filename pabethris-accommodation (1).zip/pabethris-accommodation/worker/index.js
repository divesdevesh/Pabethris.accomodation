/**
 * Pabethris Group - lead API (Cloudflare Worker + D1).
 *
 *   POST /api/leads    public, called by the website chat and forms
 *   GET  /api/leads    private, needs "Authorization: Bearer <ADMIN_TOKEN>"
 *   GET  /api/health   simple check
 */

const SOURCES = ["chat", "find-accommodation", "contact"];
const LIMITS = {
  topic: 60, audience: 80, destination: 120, move_in: 60, budget: 60,
  stay_length: 60, name: 120, email: 200, phone: 30, message: 2000, page: 200,
};
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^[+()\-.\s\d]{6,25}$/;
const MAX_BODY_BYTES = 10_000;
const RATE_LIMIT_PER_10_MIN = 3;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "";
    const allowed = (env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
    const originOk = allowed.length === 0 || allowed.includes(origin);

    const cors = {};
    if (origin && allowed.includes(origin)) {
      cors["Access-Control-Allow-Origin"] = origin;
      cors["Vary"] = "Origin";
    }

    try {
      if (url.pathname === "/api/health") return json({ ok: true }, 200, cors);

      if (url.pathname === "/api/leads") {
        if (request.method === "OPTIONS") {
          return new Response(null, {
            status: 204,
            headers: {
              ...cors,
              "Access-Control-Allow-Methods": "POST, OPTIONS",
              "Access-Control-Allow-Headers": "Content-Type",
              "Access-Control-Max-Age": "86400",
            },
          });
        }
        if (request.method === "POST") return await createLead(request, env, ctx, cors, originOk);
        if (request.method === "GET") return await listLeads(request, url, env);
        return json({ error: "Method not allowed." }, 405, { ...cors, Allow: "GET, POST, OPTIONS" });
      }

      return json({ error: "Not found." }, 404, cors);
    } catch (err) {
      console.error("Unhandled error:", err && err.stack ? err.stack : err);
      return json({ error: "Something went wrong on our side. Please try again." }, 500, cors);
    }
  },
};

/* ------------------------------------------------------------------ */

async function createLead(request, env, ctx, cors, originOk) {
  if (!originOk) return json({ error: "This website is not allowed to send requests." }, 403, cors);
  if (!env.DB) return json({ error: "Database is not configured." }, 500, cors);

  const type = request.headers.get("Content-Type") || "";
  if (!type.includes("application/json")) return json({ error: "Send JSON." }, 415, cors);

  const raw = await request.text();
  if (raw.length > MAX_BODY_BYTES) return json({ error: "Request too large." }, 413, cors);

  let data;
  try { data = JSON.parse(raw); } catch { return json({ error: "Invalid JSON." }, 400, cors); }
  if (!data || typeof data !== "object" || Array.isArray(data)) return json({ error: "Invalid request." }, 400, cors);

  /* Honeypot: bots fill this hidden field. Pretend success, store nothing. */
  if (typeof data.website === "string" && data.website.trim() !== "") return json({ ok: true }, 200, cors);

  const lead = {};
  for (const [key, max] of Object.entries(LIMITS)) {
    const v = data[key];
    lead[key] = typeof v === "string" ? clean(v).slice(0, max) : "";
  }
  lead.source = typeof data.source === "string" ? data.source : "";

  if (!SOURCES.includes(lead.source)) return json({ error: "Unknown request type." }, 400, cors);
  if (!lead.name) return json({ error: "Please enter your name." }, 400, cors);
  if (!EMAIL_RE.test(lead.email)) return json({ error: "Please enter a valid email address." }, 400, cors);
  if (lead.phone && !PHONE_RE.test(lead.phone)) return json({ error: "Please enter a valid phone number." }, 400, cors);
  if (data.consent !== true) return json({ error: "Consent is required to store your details." }, 400, cors);
  if (lead.source !== "contact" && !lead.destination) return json({ error: "Please tell us where you are moving to." }, 400, cors);
  if (lead.source === "contact" && !lead.message) return json({ error: "Please write a message." }, 400, cors);

  /* Simple rate limit per email: 3 requests per 10 minutes. */
  const since = new Date(Date.now() - 10 * 60 * 1000).toISOString();
  const recent = await env.DB.prepare("SELECT COUNT(*) AS n FROM leads WHERE email = ?1 AND created_at > ?2")
    .bind(lead.email.toLowerCase(), since).first();
  if (recent && recent.n >= RATE_LIMIT_PER_10_MIN) {
    return json({ error: "Too many requests. Please wait a few minutes and try again." }, 429, cors);
  }

  const userAgent = clean(request.headers.get("User-Agent") || "").slice(0, 200);
  const now = new Date().toISOString();

  await env.DB.prepare(
    `INSERT INTO leads
       (source, topic, audience, destination, move_in, budget, stay_length, name, email, phone, message,
        consent, consent_at, page, user_agent)
     VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, 1, ?12, ?13, ?14)`
  ).bind(
    lead.source, nul(lead.topic), nul(lead.audience), nul(lead.destination), nul(lead.move_in),
    nul(lead.budget), nul(lead.stay_length), lead.name, lead.email.toLowerCase(), nul(lead.phone),
    nul(lead.message), now, nul(lead.page), nul(userAgent)
  ).run();

  ctx.waitUntil(notify(env, lead).catch((e) => console.error("Notify failed:", e)));
  return json({ ok: true }, 200, cors);
}

async function listLeads(request, url, env) {
  if (!env.ADMIN_TOKEN) return json({ error: "Not found." }, 404);
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token || !(await safeEqual(token, env.ADMIN_TOKEN))) {
    return json({ error: "Unauthorized." }, 401, { "WWW-Authenticate": "Bearer" });
  }
  const limit = Math.min(Math.max(parseInt(url.searchParams.get("limit") || "50", 10) || 50, 1), 200);
  const status = url.searchParams.get("status");
  const query = status
    ? env.DB.prepare("SELECT * FROM leads WHERE status = ?1 ORDER BY id DESC LIMIT ?2").bind(status, limit)
    : env.DB.prepare("SELECT * FROM leads ORDER BY id DESC LIMIT ?1").bind(limit);
  const { results } = await query.all();
  return json({ count: results.length, leads: results }, 200, { "Cache-Control": "no-store" });
}

async function notify(env, lead) {
  if (!env.RESEND_API_KEY || !env.NOTIFY_TO) return;
  const fields = [
    ["Source", lead.source], ["Topic", lead.topic], ["Who it is for", lead.audience],
    ["Destination", lead.destination], ["Move-in", lead.move_in], ["Budget", lead.budget],
    ["Stay length", lead.stay_length], ["Name", lead.name], ["Email", lead.email],
    ["Phone", lead.phone], ["Message", lead.message],
  ].filter(([, v]) => v);

  const text = fields.map(([k, v]) => `${k}: ${v}`).join("\n");
  const html = "<table cellpadding='6' style='font-family:Arial,sans-serif;font-size:15px'>" +
    fields.map(([k, v]) => `<tr><td><b>${esc(k)}</b></td><td>${esc(v).replace(/\n/g, "<br>")}</td></tr>`).join("") +
    "</table>";

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: env.NOTIFY_FROM || "Pabethris Leads <onboarding@resend.dev>",
      to: [env.NOTIFY_TO],
      reply_to: lead.email,
      subject: `New lead: ${lead.name} (${lead.source})`,
      text, html,
    }),
  });
  if (!res.ok) throw new Error(`Resend responded ${res.status}`);
}

/* ------------------------------------------------------------------ */

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...headers },
  });
}
function clean(s) { return s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim(); }
function nul(s) { return s ? s : null; }
function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
async function safeEqual(a, b) {
  const enc = new TextEncoder();
  const [ha, hb] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(a)),
    crypto.subtle.digest("SHA-256", enc.encode(b)),
  ]);
  const x = new Uint8Array(ha), y = new Uint8Array(hb);
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

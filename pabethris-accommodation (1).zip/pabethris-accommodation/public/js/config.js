/* Pabethris Group - site configuration.
   Edit only this file when you deploy. */
window.PABETHRIS_CONFIG = {
  /* URL of your Cloudflare Worker lead endpoint, for example:
     "https://pabethris-api.YOUR-SUBDOMAIN.workers.dev/api/leads"
     While this is empty, forms and the chat fall back to a prefilled email. */
  LEAD_API: "",

  /* Where fallback emails are addressed. */
  EMAIL: "pabethris4@gmail.com",

  /* How long (ms) before the chat invitation bubble appears. 0 turns it off. */
  NUDGE_DELAY_MS: 9000
};

/* Pabethris Group - guided chat assistant that collects accommodation leads.
   Builds its own markup, so every page only needs the script tag. */
(function () {
  "use strict";
  if (document.getElementById("pb-chat")) return;

  var C = window.PABETHRIS_CONFIG || {};
  var PB = window.Pabethris || {};
  var V = PB.validators || { EMAIL_RE: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, PHONE_RE: /^[+()\-.\s\d]{6,25}$/ };

  var STEPS = [
    { key: "audience", type: "options", q: "Hi, I'm the Pabethris assistant. Who is the stay for?", options: ["Student", "Working professional", "Someone relocating"] },
    { key: "destination", type: "text", q: "Which city and country are you moving to?", ph: "e.g. Linz, Austria", max: 120 },
    { key: "move_in", type: "text", q: "When do you need to move in?", ph: "e.g. January 2027", max: 60 },
    { key: "budget", type: "text", q: "What is your monthly budget for rent?", ph: "e.g. 500 EUR", max: 60 },
    { key: "stay_length", type: "options", q: "How long will you stay?", options: ["Under 6 months", "6 to 12 months", "More than a year", "Not sure yet"] },
    { key: "name", type: "text", q: "Thank you. What is your name?", ph: "Full name", max: 120 },
    { key: "email", type: "email", q: "What is the best email to reach you?", ph: "you@example.com", max: 200 },
    { key: "phone", type: "phone", q: "Phone or WhatsApp number? You can skip this.", ph: "+43 660 1234567", max: 30, optional: true }
  ];

  var idx = 0, lead = {}, sending = false, finished = false, opened = false, lastFocus = null;

  function el(tag, cls, text, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    if (attrs) Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    return n;
  }

  /* ---------- Markup ---------- */
  var btn = el("button", null, null, { id: "pb-chat-btn", type: "button", "aria-label": "Open chat assistant", "aria-controls": "pb-chat", "aria-expanded": "false" });
  btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v11H9l-5 4z"/></svg>';

  var nudge = el("div", null, null, { id: "pb-nudge" });
  var nudgeOpen = el("button", "pb-nudge-open", "Need help finding a place to stay? I can help in two minutes.", { type: "button" });
  var nudgeClose = el("button", "pb-nudge-close", "\u00d7", { type: "button", "aria-label": "Dismiss" });
  nudge.appendChild(nudgeOpen); nudge.appendChild(nudgeClose);

  var panel = el("div", null, null, { id: "pb-chat", role: "dialog", "aria-label": "Pabethris assistant", tabindex: "-1" });
  var head = el("div", "pb-head");
  var title = el("div"); title.appendChild(el("b", null, "Pabethris assistant")); title.appendChild(el("small", null, "Tell us what you need"));
  var tools = el("div");
  var restartBtn = el("button", null, "Restart", { type: "button" });
  var closeBtn = el("button", "pb-x", "\u00d7", { type: "button", "aria-label": "Close chat" });
  tools.appendChild(restartBtn); tools.appendChild(closeBtn);
  head.appendChild(title); head.appendChild(tools);
  var log = el("div", null, null, { id: "pb-log", role: "log", "aria-live": "polite" });
  var form = el("form", null, null, { id: "pb-form", novalidate: "" });
  form.hidden = true;
  var input = el("input", null, null, { id: "pb-in", type: "text", autocomplete: "off", "aria-label": "Your answer" });
  var sendBtn = el("button", "btn", "Send", { type: "submit" });
  var skipBtn = el("button", "btn ghost", "Skip", { type: "button" });
  skipBtn.hidden = true;
  form.appendChild(input); form.appendChild(skipBtn); form.appendChild(sendBtn);
  panel.appendChild(head); panel.appendChild(log); panel.appendChild(form);
  document.body.appendChild(nudge); document.body.appendChild(btn); document.body.appendChild(panel);

  /* ---------- Helpers ---------- */
  function scrollDown() { log.scrollTop = log.scrollHeight; }
  function say(text, cls) { var m = el("div", "pb-m " + (cls || "bot"), text); log.appendChild(m); scrollDown(); return m; }
  function sayLink(text, href, linkText) {
    var m = el("div", "pb-m bot", text + " ");
    var a = el("a", null, linkText, { href: href });
    m.appendChild(a); log.appendChild(m); scrollDown();
  }
  function options(list, cb) {
    var w = el("div", "pb-opts");
    list.forEach(function (label) {
      var b = el("button", null, label, { type: "button" });
      b.addEventListener("click", function () { if (w.parentNode) w.parentNode.removeChild(w); cb(label); });
      w.appendChild(b);
    });
    log.appendChild(w); scrollDown();
    return w;
  }
  function showInput(step) {
    form.hidden = false;
    input.type = step.type === "email" ? "email" : (step.type === "phone" ? "tel" : "text");
    input.setAttribute("inputmode", step.type === "email" ? "email" : (step.type === "phone" ? "tel" : "text"));
    input.setAttribute("maxlength", String(step.max || 200));
    input.placeholder = step.ph || "";
    input.value = "";
    skipBtn.hidden = !step.optional;
    if (opened) input.focus();
  }
  function hideInput() { form.hidden = true; skipBtn.hidden = true; }

  /* ---------- Conversation ---------- */
  function ask() {
    if (finished) return;
    var step = STEPS[idx];
    if (!step) return askConsent();
    say(step.q);
    if (step.type === "options") { hideInput(); options(step.options, function (v) { commit(v); }); }
    else showInput(step);
  }

  function commit(value, shown) {
    var step = STEPS[idx];
    if (value) lead[step.key] = value;
    say(shown || value || "Skipped", "me");
    idx += 1;
    hideInput();
    setTimeout(ask, 300);
  }

  function askConsent() {
    hideInput();
    say("Last step. We will use these details only to find accommodation for you and to contact you about it. You can read how in our privacy policy (privacy.html). Is that okay?");
    options(["Yes, send my details", "No, don't send"], function (v) {
      say(v, "me");
      if (v.indexOf("Yes") === 0) send();
      else { finished = true; say("No problem, nothing was sent. You can also email us at " + C.EMAIL + "."); offerRestart(); }
    });
  }

  function offerRestart() { options(["Start a new request"], function () { reset(); }); }

  function send() {
    if (sending) return;
    sending = true;
    var wait = say("Sending your details...");
    var payload = { source: "chat", consent: true, page: location.pathname };
    Object.keys(lead).forEach(function (k) { payload[k] = lead[k]; });
    var submit = PB.submitLead || function () { return Promise.resolve({ ok: false, reason: "no-endpoint", mailto: "mailto:" + C.EMAIL }); };
    submit(payload).then(function (r) {
      sending = false; finished = true;
      if (wait.parentNode) wait.parentNode.removeChild(wait);
      if (r.ok) {
        say("Thank you, " + (lead.name || "there") + ". Our team will email you at " + lead.email + " with options that match.");
      } else if (r.reason === "no-endpoint") {
        sayLink("Online sending is not switched on yet.", r.mailto, "Tap here to email us your request.");
      } else if (r.status === 429) {
        sayLink("Too many requests right now. Please try again in a few minutes, or", r.mailto, "email us instead.");
      } else {
        sayLink("We could not send your details just now.", r.mailto, "Email us instead.");
      }
      offerRestart();
    });
  }

  function reset() {
    idx = 0; lead = {}; sending = false; finished = false;
    log.textContent = "";
    hideInput();
    ask();
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var step = STEPS[idx];
    if (!step || finished || sending) return;
    var v = input.value.trim();
    if (!v && !step.optional) { say("Please type an answer to continue.", "bot err"); return; }
    if (step.type === "email" && !V.EMAIL_RE.test(v)) { say("That email does not look right. Please check it and try again.", "bot err"); return; }
    if (step.type === "phone" && v && !V.PHONE_RE.test(v)) { say("That phone number does not look right. Use digits, spaces and + only, or tap Skip.", "bot err"); return; }
    commit(v);
  });
  skipBtn.addEventListener("click", function () { if (STEPS[idx] && STEPS[idx].optional) commit(""); });
  restartBtn.addEventListener("click", reset);

  /* ---------- Open / close ---------- */
  function openChat() {
    lastFocus = document.activeElement;
    panel.classList.add("open");
    btn.setAttribute("aria-expanded", "true");
    btn.setAttribute("aria-label", "Close chat assistant");
    nudge.classList.remove("show");
    opened = true;
    if (!log.childNodes.length) ask();
    if (!form.hidden) input.focus();
    else { var first = log.querySelector(".pb-opts button"); (first || panel).focus(); }
  }
  function closeChat() {
    panel.classList.remove("open");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-label", "Open chat assistant");
    var target = (lastFocus && lastFocus !== document.body && document.contains(lastFocus)) ? lastFocus : btn;
    target.focus();
  }
  function toggle() { panel.classList.contains("open") ? closeChat() : openChat(); }

  btn.addEventListener("click", toggle);
  closeBtn.addEventListener("click", closeChat);
  nudgeOpen.addEventListener("click", openChat);
  nudgeClose.addEventListener("click", function () {
    nudge.classList.remove("show");
    try { sessionStorage.setItem("pb-nudge-dismissed", "1"); } catch (e) {}
  });
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-chat-open]");
    if (t) { e.preventDefault(); if (!panel.classList.contains("open")) openChat(); }
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && panel.classList.contains("open")) closeChat();
  });

  /* Invitation bubble: once per visit, never after the chat was opened */
  var delay = Number(C.NUDGE_DELAY_MS);
  var dismissed = false;
  try { dismissed = sessionStorage.getItem("pb-nudge-dismissed") === "1"; } catch (e) {}
  if (delay > 0 && !dismissed) {
    setTimeout(function () { if (!opened) nudge.classList.add("show"); }, delay);
  }
})();

/* Pabethris Group - lead submission and form handling.
   Exposes window.Pabethris.submitLead(lead) for the chat widget too. */
(function () {
  "use strict";

  var C = window.PABETHRIS_CONFIG || {};
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var PHONE_RE = /^[+()\-.\s\d]{6,25}$/;

  var LABELS = {
    topic: "Topic",
    audience: "Who it is for",
    destination: "Destination",
    move_in: "Move-in",
    budget: "Monthly budget",
    stay_length: "Stay length",
    name: "Name",
    email: "Email",
    phone: "Phone",
    message: "Message"
  };

  function mailtoLink(lead) {
    var lines = [];
    Object.keys(LABELS).forEach(function (k) {
      if (lead[k]) lines.push(LABELS[k] + ": " + lead[k]);
    });
    var body = lines.join("\n").slice(0, 1500);
    var subject = "New request from " + (lead.name || "website visitor");
    return "mailto:" + (C.EMAIL || "") + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
  }

  /* Resolves {ok:true} or {ok:false, reason, message, mailto}. Never rejects. */
  function submitLead(lead) {
    lead = lead || {};
    lead.page = lead.page || location.pathname;
    if (!C.LEAD_API) {
      return Promise.resolve({ ok: false, reason: "no-endpoint", mailto: mailtoLink(lead) });
    }
    var ctrl = typeof AbortController === "function" ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 15000);
    return fetch(C.LEAD_API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(lead),
      signal: ctrl ? ctrl.signal : undefined
    })
      .then(function (res) {
        return res.json().catch(function () { return null; }).then(function (data) {
          if (res.ok) return { ok: true };
          return { ok: false, reason: "server", status: res.status, message: data && data.error, mailto: mailtoLink(lead) };
        });
      })
      .catch(function () {
        return { ok: false, reason: "network", mailto: mailtoLink(lead) };
      })
      .then(function (r) { clearTimeout(timer); return r; });
  }

  window.Pabethris = window.Pabethris || {};
  window.Pabethris.submitLead = submitLead;
  window.Pabethris.validators = { EMAIL_RE: EMAIL_RE, PHONE_RE: PHONE_RE };

  /* ---------- Form wiring ---------- */
  function todayISO() {
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + m + "-" + day;
  }

  function fieldError(input) {
    var v = (input.type === "checkbox" ? "" : input.value.trim());
    if (input.type === "checkbox") {
      if (input.required && !input.checked) return "Please tick this box to continue.";
      return "";
    }
    if (input.required && !v) return "This field is required.";
    if (!v) return "";
    if (input.type === "email" && !EMAIL_RE.test(v)) return "Enter a valid email, like name@example.com.";
    if (input.type === "tel" && !PHONE_RE.test(v)) return "Enter a valid phone number, for example +43 660 1234567.";
    if (input.type === "date" && v < todayISO()) return "Choose today or a future date.";
    return "";
  }

  function showError(input, msg) {
    var err = document.getElementById(input.id + "-err");
    if (err) err.textContent = msg;
    if (msg) {
      input.setAttribute("aria-invalid", "true");
      if (err) input.setAttribute("aria-describedby", err.id);
    } else {
      input.removeAttribute("aria-invalid");
      input.removeAttribute("aria-describedby");
    }
  }

  function setStatus(box, kind, text, mailto) {
    box.className = "status show " + kind;
    box.textContent = text;
    if (mailto) {
      box.appendChild(document.createTextNode(" "));
      var a = document.createElement("a");
      a.href = mailto;
      a.textContent = "Send the same details by email instead";
      box.appendChild(a);
      box.appendChild(document.createTextNode("."));
    }
  }

  function initForm(form) {
    var source = form.getAttribute("data-source") || "form";
    var status = form.querySelector(".status");
    var button = form.querySelector('button[type="submit"]');
    var inputs = Array.prototype.slice.call(form.querySelectorAll("input, select, textarea"))
      .filter(function (i) { return i.name && i.name !== "website"; });

    Array.prototype.forEach.call(form.querySelectorAll('input[type="date"]'), function (d) { d.min = todayISO(); });

    /* contact.html?topic=landlord preselects the topic */
    var topicSel = form.querySelector('select[name="topic"]');
    if (topicSel) {
      try {
        var wanted = new URLSearchParams(location.search).get("topic");
        var map = { landlord: "Landlord partnership", general: "General question", other: "Other" };
        if (wanted && map[wanted.toLowerCase()]) topicSel.value = map[wanted.toLowerCase()];
      } catch (e) {}
    }

    inputs.forEach(function (input) {
      input.addEventListener("blur", function () { if (input.value || input.type === "checkbox") showError(input, fieldError(input)); });
      input.addEventListener("input", function () { if (input.getAttribute("aria-invalid")) showError(input, fieldError(input)); });
      input.addEventListener("change", function () { if (input.getAttribute("aria-invalid")) showError(input, fieldError(input)); });
    });

    var busy = false;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (busy) return;

      var firstBad = null;
      inputs.forEach(function (input) {
        var msg = fieldError(input);
        showError(input, msg);
        if (msg && !firstBad) firstBad = input;
      });
      if (firstBad) {
        setStatus(status, "bad", "Please fix the highlighted fields and try again.");
        firstBad.focus();
        return;
      }

      var hp = form.querySelector('[name="website"]');
      if (hp && hp.value) { /* bot: pretend success, send nothing */
        form.reset();
        setStatus(status, "ok", "Thank you. Our team will contact you soon.");
        return;
      }

      var lead = { source: source, consent: true };
      inputs.forEach(function (input) {
        if (input.type === "checkbox") return;
        var v = input.value.trim();
        if (v) lead[input.name] = v;
      });
      lead.page = location.pathname;

      busy = true;
      if (button) { button.disabled = true; button.setAttribute("data-label", button.textContent); button.textContent = "Sending..."; }
      setStatus(status, "", "Sending your details...");

      submitLead(lead).then(function (r) {
        busy = false;
        if (button) { button.disabled = false; button.textContent = button.getAttribute("data-label") || "Send"; }
        if (r.ok) {
          form.reset();
          setStatus(status, "ok", "Thank you, " + (lead.name || "") + ". We received your details and will email you soon.");
        } else if (r.reason === "no-endpoint") {
          setStatus(status, "bad", "Online sending is not switched on yet.", r.mailto);
        } else if (r.status === 429) {
          setStatus(status, "bad", "Too many requests. Please wait a few minutes and try again.", r.mailto);
        } else if (r.status === 400 && r.message) {
          setStatus(status, "bad", r.message, r.mailto);
        } else {
          setStatus(status, "bad", "We could not send your details just now.", r.mailto);
        }
        status.focus && status.focus();
      });
    });
  }

  Array.prototype.forEach.call(document.querySelectorAll("form[data-lead-form]"), initForm);
})();

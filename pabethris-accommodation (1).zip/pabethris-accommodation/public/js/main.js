/* Pabethris Group - shared behaviour: mobile menu and photo loading. */
(function () {
  "use strict";

  /* ---------- Mobile menu ---------- */
  var toggle = document.getElementById("menu-toggle");
  var links = document.getElementById("nav-links");

  function setMenu(open) {
    if (!toggle || !links) return;
    links.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  }

  if (toggle && links) {
    toggle.addEventListener("click", function () {
      setMenu(!links.classList.contains("open"));
    });
    links.addEventListener("click", function (e) {
      if (e.target.closest("a, button")) setMenu(false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && links.classList.contains("open")) {
        setMenu(false);
        toggle.focus();
      }
    });
    document.addEventListener("click", function (e) {
      if (links.classList.contains("open") && !e.target.closest(".site-header")) setMenu(false);
    });
    window.addEventListener("resize", function () {
      if (window.innerWidth > 900) setMenu(false);
    });
  }

  /* ---------- Photos: show a photo only if the file exists ---------- */
  Array.prototype.forEach.call(document.querySelectorAll("[data-img]"), function (el) {
    var src = el.getAttribute("data-img");
    if (!src) return;
    var img = new Image();
    img.onload = function () {
      el.style.setProperty("--img", 'url("' + src + '")');
      el.classList.add("has");
    };
    img.src = src;
  });
})();

-- Pabethris Group - Cloudflare D1 schema (SQLite).
-- Create the database:   npx wrangler d1 create pabethris-leads
-- Apply this schema:     cd worker && npx wrangler d1 execute pabethris-leads --remote --file=../database/schema.sql

CREATE TABLE IF NOT EXISTS leads (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  source       TEXT    NOT NULL CHECK (source IN ('chat','find-accommodation','contact')),
  topic        TEXT,                -- contact form only
  audience     TEXT,                -- student / professional / relocating
  destination  TEXT,
  move_in      TEXT,
  budget       TEXT,
  stay_length  TEXT,
  name         TEXT    NOT NULL,
  email        TEXT    NOT NULL,
  phone        TEXT,
  message      TEXT,
  consent      INTEGER NOT NULL DEFAULT 0 CHECK (consent IN (0,1)),
  consent_at   TEXT,
  page         TEXT,                -- page the visitor was on
  user_agent   TEXT,                -- for spam checks only
  status       TEXT    NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','matched','closed','spam')),
  notes        TEXT                 -- your own internal notes
);

CREATE INDEX IF NOT EXISTS idx_leads_created ON leads (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_email   ON leads (email, created_at);
CREATE INDEX IF NOT EXISTS idx_leads_status  ON leads (status);

-- Handy queries (run with: npx wrangler d1 execute pabethris-leads --remote --command "...")
--   SELECT id, created_at, name, email, destination, move_in, budget FROM leads WHERE status = 'new' ORDER BY id DESC;
--   UPDATE leads SET status = 'contacted', notes = 'Emailed options' WHERE id = 1;
--   DELETE FROM leads WHERE email = 'person@example.com';   -- honour a deletion request

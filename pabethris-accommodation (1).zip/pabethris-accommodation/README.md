# Pabethris Group website

Static website (HTML, CSS, JavaScript) plus a small Cloudflare Worker and a D1 database
that receive and store leads from the chat assistant and the forms.

```
pabethris-accommodation/
  public/      the website (this is the folder you publish)
    index.html  find-accommodation.html  partners.html  about.html
    contact.html  privacy.html  terms.html  404.html
    css/main.css  css/chat.css
    js/config.js  js/main.js  js/forms.js  js/chat.js
    images/  fonts/  _headers  robots.txt  favicon.ico
  worker/      Cloudflare Worker (index.js, wrangler.toml)
  database/    schema.sql
  brand/       your original logo file
```

Only `public/` is published. Keep `worker/` and `database/` out of the website.

## 1. Add your photos

Put these files in `public/images/rooms/` (JPG, about 1600 px wide, under 300 KB each):

| File | Used for |
|---|---|
| `student-room.jpg` | hero (large tile) and gallery |
| `shared-apartment.jpg` | hero and gallery |
| `studio.jpg` | hero and gallery |
| `professional-apartment.jpg` | gallery |

Put your portrait at `public/images/founder.jpg` (4:5 portrait works best).
A missing photo simply shows the gold placeholder tile, so nothing breaks.
Use only photos you own or have written permission to use.

## 2. Try it on your computer

```
cd public
python3 -m http.server 8000
```
Open http://localhost:8000. Until step 4 is done, forms and chat offer a prefilled email instead.

## 3. Create the database and the worker

You need a free Cloudflare account and Node.js.

```
cd worker
npx wrangler login
npx wrangler d1 create pabethris-leads
```
Copy the `database_id` it prints into `worker/wrangler.toml`. Then:

```
npx wrangler d1 execute pabethris-leads --remote --file=../database/schema.sql
npx wrangler secret put ADMIN_TOKEN        # type a long random string
npx wrangler deploy
```
Wrangler prints your worker address, like `https://pabethris-api.YOURNAME.workers.dev`.

Optional email alert for every new lead: create a free account at resend.com, then
`npx wrangler secret put RESEND_API_KEY`. (Until you verify your own domain at Resend,
it only delivers to the email address you signed up with.)

## 4. Connect the site to the worker

1. Open `public/js/config.js` and set
   `LEAD_API: "https://pabethris-api.YOURNAME.workers.dev/api/leads"`.
2. In `worker/wrangler.toml`, put your real site address in `ALLOWED_ORIGINS`
   (for example `https://pabethris.pages.dev,https://www.yourdomain.com`), then run `npx wrangler deploy` again.

## 5. Publish the website

Cloudflare dashboard > Workers & Pages > Create > Pages > Upload assets, then upload the
**contents of the `public` folder**. (Or run `npx wrangler pages deploy public --project-name pabethris`.)

## 6. Read your leads

```
curl -H "Authorization: Bearer YOUR_ADMIN_TOKEN" "https://pabethris-api.YOURNAME.workers.dev/api/leads?limit=50"
```
Or in SQL:
```
cd worker
npx wrangler d1 execute pabethris-leads --remote --command "SELECT id, created_at, name, email, destination, move_in, budget FROM leads WHERE status='new' ORDER BY id DESC"
```

## Before you go live

- Have a lawyer review `privacy.html` and `terms.html`. They are drafts. Check the retention period (24 months) and the governing-law line.
- If you add Google Analytics, ads or any third-party script, update the privacy policy and `_headers` (`script-src`, `connect-src`).
- When you have a domain, add `og:image` and `og:url` meta tags with full web addresses so shared links show a preview (use `images/og-image.png`).
- If you use your own worker domain instead of workers.dev, add it to `connect-src` in `public/_headers`.
- Add the Uniplaces affiliate links and wording as your partner agreement allows, and keep the disclosure line.

## Editing the pages

The HTML files are plain files. Edit them directly. Shared header and footer are repeated in each page,
so change them in every file (search for `site-header` and `site-footer`).
Colours and fonts are variables at the top of `public/css/main.css`.
